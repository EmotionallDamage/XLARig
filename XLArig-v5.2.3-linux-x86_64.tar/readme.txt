Here's the instructions to use one of the examples as your configuration file :

CASE A : If you want to use the json file

1. Rename the file "config_example.json" to "config.json"
2. Open it with your favorite text editor
3. Edit the pool, wallet and password lines
4. Start xlarig

Case B : If you want to use the script file

1. Rename the "config_example.sh" to anything simple for you (example : xla_start_mining.sh)
2. Open it with your favorite text editor
3. Edit the pool, wallet and password with your own information.
4. Start the script